/**
 * 测试组件，用于单元测试、集成测试等等
 */
package cn.iocoder.yudao.framework.test;
