/**
 * 消息队列，支持 Redis、RocketMQ、RabbitMQ、Kafka 四种
 */
package cn.iocoder.yudao.framework.mq;
