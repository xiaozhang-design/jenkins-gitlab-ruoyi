<http://www.iocoder.cn/Spring-Boot/RabbitMQ/?yudao>
