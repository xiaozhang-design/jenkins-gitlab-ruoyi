/**
 * 字典数据模块，提供 {@link cn.iocoder.yudao.framework.dict.core.DictFrameworkUtils} 工具类
 *
 * 通过将字典缓存在内存中，保证性能
 */
package cn.iocoder.yudao.framework.dict;
