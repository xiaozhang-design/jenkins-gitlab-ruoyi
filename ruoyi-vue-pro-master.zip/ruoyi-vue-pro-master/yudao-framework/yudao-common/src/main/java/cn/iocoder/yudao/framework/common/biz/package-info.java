/**
 * 特殊：用于 framework 下，starter 需要调用 biz 业务模块的接口定义！
 */
package cn.iocoder.yudao.framework.common.biz;