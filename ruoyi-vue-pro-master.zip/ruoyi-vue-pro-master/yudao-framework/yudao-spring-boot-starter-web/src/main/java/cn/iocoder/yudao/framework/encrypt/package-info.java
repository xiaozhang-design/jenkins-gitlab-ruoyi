/**
 * HTTP API 加密组件：支持 Request 和 Response 的加密、解密
 */
package cn.iocoder.yudao.framework.encrypt;