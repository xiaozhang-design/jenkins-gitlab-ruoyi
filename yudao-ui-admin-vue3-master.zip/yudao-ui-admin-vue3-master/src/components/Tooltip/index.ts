import Tooltip from './src/Tooltip.vue'

export { Tooltip }
