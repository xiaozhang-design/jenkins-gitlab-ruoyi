import Sticky from './src/Sticky.vue'

export { Sticky }
