import Icon from './src/Icon.vue'
import IconSelect from './src/IconSelect.vue'

export { Icon, IconSelect }
