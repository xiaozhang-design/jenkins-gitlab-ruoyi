import InputPassword from './src/InputPassword.vue'

export { InputPassword }
