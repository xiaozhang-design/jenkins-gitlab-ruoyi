import IFrame from './src/IFrame.vue'

export { IFrame }
