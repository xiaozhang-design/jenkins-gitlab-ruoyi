import OperateLogV2 from './src/OperateLogV2.vue'

export { OperateLogV2 }
